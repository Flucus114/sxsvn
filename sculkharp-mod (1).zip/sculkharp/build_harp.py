#!/usr/bin/env python3
"""Constrói a Harpa de Sculk: modelos JSON de item (4 estágios), atlas de textura e sprites de partículas.

Estrutura (vista de FRENTE = lado das cordas, que fica voltado para o jogador, face +Z do modelo):
  - base retangular robusta embaixo, coluna vertical à ESQUERDA, braço diagonal à DIREITA (do pé da base até o topo da coluna);
  - cordas verticais, uniformemente espaçadas, entre a coluna e o braço diagonal (base -> braço);
  - cristais de sculk no topo da coluna, na junção do braço e nas pontas da base.

Técnica (igual à do arco): a silhueta é voxelizada (voxel = 0,5 px do modelo), cada voxel tem uma faixa de profundidade em Z
e a arte da vista frontal é pintada num "sheet" (2x2 texels por voxel). As faces ±Z usam a janela do sheet na própria
posição XY; as paredes usam a janela do voxel vizinho. Brilho (cristais, cordas, fragmentos) via forge_data por face.

Estágios (item property "playing" / "power"):  0 repouso | 1 tocando | 2 carga >= 50% | 3 carga total.
IMPORTANTE: os UVs do JSON são sempre 0..16, qualquer que seja a resolução da textura.
Uso: python3 build_harp.py
"""
import json, os, random
import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(ROOT, "src/main/resources/assets/sculkharp")
NAME = "sculk_harp"

# ---------------------------------------------------------------- paleta (#081A24 #103F4B #1A6E7D #00E5FF #5DEFFF)
P0, P1, P2 = (8, 26, 36), (16, 63, 75), (26, 110, 125)
P3, P4 = (0, 229, 255), (93, 239, 255)
C1 = (8, 160, 185)           # intermediário P2->P3 só nas facetas dos cristais

# ---------------------------------------------------------------- grade
W, H = 30, 44                # voxels (15 x 22 px)
V = 0.5                      # tamanho do voxel (px do modelo)
X0 = 8.0 - W * V / 2         # canto esquerdo
YTOP = 8.0 + H * V / 2       # topo
ZC = 8.0
TW, TH = 64, 96              # atlas: sheet 60x88 em (0,0); tile de fragmento 8x8 em (0,88)
SHARD = (0, 88)

BASE_R0, BASE_R1 = 38, 43    # linhas da base
COL_C0, COL_C1 = 1, 6        # colunas da coluna vertical
COL_R0 = 12                  # topo da coluna (capitel)
ARM_TOP_R, ARM_BOT_R = 13, 37
ARM_C_TOP, ARM_C_BOT = 7.0, 26.5
ARM_W = 5
STRING_COLS = (9, 12, 15, 18, 21)

rng = random.Random(1337)
cells = {}                   # (c,r) -> dict(m, zb, zf, ...)

def q(v): return round(v * 4) / 4.0

def put(c, r, m, zh, zfx=0.0, zbx=0.0, **kw):
    if 0 <= c < W and 0 <= r < H:
        cells[(c, r)] = dict(m=m, zb=q(-zh - zbx), zf=q(zh + zfx), **kw)

def arm_center(r): return ARM_C_TOP + (r - ARM_TOP_R) * (ARM_C_BOT - ARM_C_TOP) / (ARM_BOT_R - ARM_TOP_R)
def arm_cols(r):
    cen = arm_center(r); return int(round(cen - ARM_W / 2)), int(round(cen + ARM_W / 2)) - 1

# ---- base robusta (com pés mais fundos nas pontas e chanfro embaixo)
for r in range(BASE_R0, BASE_R1 + 1):
    for c in range(W):
        if r == BASE_R1 and (c < 1 or c > W - 2): continue
        put(c, r, "base", 1.5)
for r in range(BASE_R0 - 1, BASE_R1 + 1):            # pés
    for c in list(range(0, 3)) + list(range(W - 3, W)):
        if r == BASE_R1 and (c in (0, W - 1)): continue
        put(c, r, "base", 2.0)
# ---- coluna vertical + capitel
for r in range(COL_R0, BASE_R0):
    for c in range(COL_C0, COL_C1 + 1):
        put(c, r, "column", 1.25)
for r in (COL_R0, COL_R0 + 1):
    for c in range(COL_C0 - 1, COL_C1 + 2):
        put(c, r, "column", 1.5)
# ---- braço diagonal (pegada mais grossa na parte de baixo, onde a mão principal segura)
for r in range(ARM_TOP_R, ARM_BOT_R + 1):
    a, b = arm_cols(r)
    for c in range(a, b + 1):
        if r >= 29: put(c, r, "grip", 1.5)
        else: put(c, r, "arm", 1.0)
# ---- cordas (entre a base e a parte de baixo do braço)
arm_cells = {(c, r) for (c, r), d in cells.items() if d["m"] in ("arm", "grip")}
for sc in STRING_COLS:
    top = None
    for r in range(BASE_R0 - 1, ARM_TOP_R - 1, -1):
        if (sc, r) in arm_cells: top = r; break
    top = ARM_TOP_R if top is None else top
    for r in range(top + 1, BASE_R0):
        put(sc, r, "string", 0.25, sr=r, sc=sc)

# ---- cristais irregulares
def spire(c0, base_r, width, height, lean, zh, gid):
    for k in range(height):
        r = base_r - k
        w = width if k < height * 0.62 else max(1, width - 1)
        if k >= height - 2: w = 1
        shift = int(k * lean) + (width - w) // 2
        for i in range(w):
            c = c0 + shift + i
            rel = (i + (width - w) // 2) / max(1, width - 1)       # 0 esquerda .. 1 direita
            put(c, r, "crystal", zh + 0.25 * ((k + gid) % 3 == 0), zfx=0.25 * (gid % 2),
                shade=1.0 - rel, tipd=k / max(1, height - 1), gid=gid)
# topo da coluna
spire(0, 11, 2, 6, 0.0, 0.75, 1)
spire(2, 11, 2, 10, 0.1, 1.0, 2)
spire(4, 11, 3, 13, 0.0, 1.25, 3)
spire(7, 11, 2, 8, -0.1, 1.0, 4)
spire(9, 12, 1, 5, 0.2, 0.75, 5)
# junção do braço com a coluna (extremidade superior)
spire(10, 13, 2, 6, 0.25, 0.75, 6)
spire(13, 15, 1, 4, 0.25, 0.75, 7)
spire(12, 15, 2, 4, 0.25, 0.5, 8)
# pontas da base
spire(0, BASE_R0 - 2, 1, 6, 0.0, 0.75, 9)
spire(W - 1, BASE_R0 - 2, 1, 8, -0.1, 0.75, 10)

# ---- fragmentos luminosos (nós brilhantes embutidos na estrutura)
cand = [(c, r) for (c, r), d in cells.items() if d["m"] in ("column", "arm", "base", "grip")]
rng.shuffle(cand)
for (c, r) in cand[:22]:
    d = cells[(c, r)]
    put(c, r, "glow", (d["zf"] - d["zb"]) / 2.0, zfx=0.25, zbx=0.25)

EMIS = {"crystal", "string", "glow"}

# ---------------------------------------------------------------- pintura do sheet
SW, SH = W * 2, H * 2
def smooth_noise(seed, block):
    g = np.random.RandomState(seed)
    small = g.rand(SH // block + 2, SW // block + 2)
    return np.kron(small, np.ones((block, block)))[:SH, :SW]

def paint(stage):
    g = np.random.RandomState(7)
    n_big, n_mid = smooth_noise(11, 6), smooth_noise(12, 2)
    jit = g.rand(SH, SW)
    img = np.zeros((TH, TW, 4), np.uint8)
    boost = (0.0, 0.0, 0.10, 0.22)[stage]
    for (c, r), d in cells.items():
        m = d["m"]
        for ty in range(2):
            for tx in range(2):
                x, y = c * 2 + tx, r * 2 + ty
                n = 0.45 * n_big[y, x] + 0.4 * n_mid[y, x] + 0.15 * jit[y, x]
                if m in ("base", "column", "arm", "grip"):
                    if m == "column": n += 0.10 * np.sin(x * 1.7) + (0.08 if (x % 4 < 2) else -0.05)
                    if m == "arm":    n += 0.10 * np.sin((x * 0.85 + y * 0.62) * 1.9)
                    if m == "base":   n += (0.12 if (y % 6 < 1) else 0.0) + (0.06 if ((x + (y // 6) * 5) % 12 < 1) else 0.0)
                    if m == "grip":   n += 0.18 if (r % 3 == 0) else -0.04
                    col = P0 if n < 0.36 else (P1 if n < 0.80 else P2)
                    sp = jit[y, x]
                    if sp > 0.985 - 0.01 * (m == "column"): col = P3 if stage >= 1 or sp > 0.992 else P2
                    if m == "grip" and r % 6 == 0 and tx == 0: col = P2
                    if (c, r) in arm_cells and r == ARM_TOP_R - 0 and ty == 0: col = P2
                elif m == "crystal":
                    t = 0.55 * d["tipd"] + 0.45 * d["shade"] + 0.09 * (d["gid"] % 3 - 1) + (jit[y, x] - 0.5) * 0.28 + boost
                    if d["tipd"] < 0.12: t = min(t, 0.30)
                    col = P2 if t < 0.28 else C1 if t < 0.46 else P3 if t < 0.74 else P4
                    if tx == 0 and d["shade"] > 0.6 and col == P3: col = P4 if jit[y, x] > 0.55 else col
                elif m == "string":
                    node = (d["sr"] % 5 == 0) or (stage >= 1 and (d["sr"] + stage) % 3 == 0)
                    core = P4 if (stage >= 1 or node) else P3
                    col = core if (tx == 1 or node or stage >= 1) else P3
                else:  # glow
                    col = P4 if (tx == 0 and ty == 0) else P3
                img[y, x] = col + (255,)
    # tile de fragmento flutuante (8x8)
    for y in range(8):
        for x in range(8):
            t = (7 - y) / 7.0 * 0.6 + (1 - x / 7.0) * 0.4 + (jit[y, x] - 0.5) * 0.2
            col = C1 if t < 0.35 else P3 if t < 0.7 else P4
            img[SHARD[1] + y, SHARD[0] + x] = col + (255,)
    return Image.fromarray(img, "RGBA")

STAGE_NAMES = [NAME, NAME + "_playing", NAME + "_power1", NAME + "_power2"]
os.makedirs(os.path.join(RES, "textures/item"), exist_ok=True)
for st, nm in enumerate(STAGE_NAMES):
    paint(st).save(os.path.join(RES, f"textures/item/{nm}.png"))

# ---------------------------------------------------------------- malha
def gx(c): return X0 + c * V
def gy(r): return YTOP - r * V
def r4(v): return round(v, 4)
def uvw(c0, r0, c1, r1, flip=False, inset=0.15):
    u0, v0, u1, v1 = c0 * 2, r0 * 2, (c1 + 1) * 2, (r1 + 1) * 2
    fx, fy = 16.0 / TW, 16.0 / TH
    a = [round((u0 + inset) * fx, 4), round((v0 + inset) * fy, 4), round((u1 - inset) * fx, 4), round((v1 - inset) * fy, 4)]
    return [a[2], a[1], a[0], a[3]] if flip else a

LIGHT = {  # [estágio] -> (cristais, cordas, fragmentos)
    0: (7, 8, 10), 1: (9, 15, 12), 2: (13, 15, 14), 3: (15, 15, 15)}
def face(uvr, em, stage, tex="#0"):
    f = {"uv": uvr, "texture": tex}
    if em:
        lv = {"crystal": LIGHT[stage][0], "string": LIGHT[stage][1], "glow": LIGHT[stage][2]}[em]
        f["forge_data"] = {"block_light": lv, "sky_light": lv}
    return f

def build_elements(stage):
    els = []
    def add(frm, to, fname, uvr, em):
        els.append({"from": [r4(v) for v in frm], "to": [r4(v) for v in to], "faces": {fname: face(uvr, em, stage)}})
    # faces grandes +Z/-Z: retângulos de voxels com mesma profundidade e mesma classe de emissão
    done = set()
    def key(c, r):
        d = cells.get((c, r)); return None if d is None else (d["zb"], d["zf"], d["m"] if d["m"] in EMIS else "")
    for r in range(H):
        for c in range(W):
            if (c, r) not in cells or (c, r) in done: continue
            k = key(c, r)
            c1 = c
            while (c1 + 1, r) in cells and (c1 + 1, r) not in done and key(c1 + 1, r) == k: c1 += 1
            r1 = r
            while r1 + 1 < H and all((cc, r1 + 1) in cells and (cc, r1 + 1) not in done and key(cc, r1 + 1) == k for cc in range(c, c1 + 1)): r1 += 1
            for rr in range(r, r1 + 1):
                for cc in range(c, c1 + 1): done.add((cc, rr))
            d = cells[(c, r)]; em = d["m"] if d["m"] in EMIS else None
            xa, xb, ya, yb = gx(c), gx(c1 + 1), gy(r1 + 1), gy(r)
            add([xa, ya, ZC + d["zf"]], [xb, yb, ZC + d["zf"]], "south", uvw(c, r, c1, r1), em)
            add([xa, ya, ZC + d["zb"]], [xb, yb, ZC + d["zb"]], "north", uvw(c, r, c1, r1, flip=True), em)
    # paredes: parte do intervalo Z do voxel que o vizinho não cobre; fundidas em corridas
    dirs = {"east": (1, 0), "west": (-1, 0), "up": (0, -1), "down": (0, 1)}
    pieces = {}
    for (c, r), d in cells.items():
        for fn, (dc, dr) in dirs.items():
            nb = cells.get((c + dc, r + dr))
            segs = [(d["zb"], d["zf"])]
            if nb:
                a, b = nb["zb"], nb["zf"]; out = []
                for (s0, s1) in segs:
                    if s0 < a: out.append((s0, min(s1, a)))
                    if s1 > b: out.append((max(s0, b), s1))
                segs = [s for s in out if s[1] - s[0] > 1e-6]
            for s in segs:
                pieces.setdefault((fn, s, d["m"] if d["m"] in EMIS else "", (r if fn in ("up", "down") else c)), []).append((c, r))
    for (fn, (z0, z1), em, _), lst in pieces.items():
        lst.sort(key=lambda t: (t[1], t[0]) if fn in ("up", "down") else (t[0], t[1]))
        runs, cur = [], [lst[0]]
        for p in lst[1:]:
            prev = cur[-1]
            if (fn in ("up", "down") and p[1] == prev[1] and p[0] == prev[0] + 1) or (fn in ("east", "west") and p[0] == prev[0] and p[1] == prev[1] + 1):
                cur.append(p)
            else: runs.append(cur); cur = [p]
        runs.append(cur)
        for run in runs:
            (ca, ra), (cb, rb) = run[0], run[-1]
            e = em or None
            za, zb_ = ZC + z0, ZC + z1
            win = uvw(ca, ra, cb, rb)
            if fn in ("up", "down"):
                y = gy(ra) if fn == "up" else gy(ra + 1)
                add([gx(ca), y, za], [gx(cb + 1), y, zb_], fn, win, e)
            else:
                x = gx(ca + 1) if fn == "east" else gx(ca)
                add([x, gy(rb + 1), za], [x, gy(ra), zb_], fn, win, e)
    # fragmentos flutuantes de energia (carga): cubinhos em volta dos cristais
    nshards = (0, 0, 5, 12)[stage]
    sr = random.Random(99)
    hu = [round(SHARD[0] * 16.0 / TW + 0.1, 4), round(SHARD[1] * 16.0 / TH + 0.1, 4),
          round((SHARD[0] + 8) * 16.0 / TW - 0.1, 4), round((SHARD[1] + 8) * 16.0 / TH - 0.1, 4)]
    anchors = [(gx(4), gy(2)), (gx(2), gy(6)), (gx(7), gy(8)), (gx(11), gy(12)), (gx(28), gy(32)), (gx(1), gy(34))]
    for i in range(nshards):
        ax, ay = anchors[i % len(anchors)]
        s = sr.choice((0.5, 0.5, 0.75))
        x, y, z = ax + sr.uniform(-1.6, 1.6), ay + sr.uniform(-1.4, 1.8), ZC + sr.choice((-1, 1)) * sr.uniform(2.2, 3.4)
        faces = {fn: {"uv": hu, "texture": "#0", "forge_data": {"block_light": 15, "sky_light": 15}}
                 for fn in ("north", "east", "south", "west", "up", "down")}
        els.append({"from": [r4(x), r4(y), r4(z)], "to": [r4(x + s), r4(y + s), r4(z + s)], "faces": faces})
    return els

DISPLAY = json.load(open(os.path.join(ROOT, "modelsrc/harp_display.json"))) if os.path.exists(os.path.join(ROOT, "modelsrc/harp_display.json")) else {}

def save(nm, m):
    with open(os.path.join(RES, "models/item", nm + ".json"), "w", encoding="utf-8") as f:
        json.dump(m, f, separators=(",", ":"))

os.makedirs(os.path.join(RES, "models/item"), exist_ok=True)
overrides = [
    {"predicate": {"playing": 1}, "model": f"sculkharp:item/{STAGE_NAMES[1]}"},
    {"predicate": {"playing": 1, "power": 0.5}, "model": f"sculkharp:item/{STAGE_NAMES[2]}"},
    {"predicate": {"playing": 1, "power": 1.0}, "model": f"sculkharp:item/{STAGE_NAMES[3]}"},
]
total = 0
for st, nm in enumerate(STAGE_NAMES):
    els = build_elements(st)
    for e in els: assert all(-16 <= v <= 32 for v in e["from"] + e["to"]), e
    m = {"textures": {"0": f"sculkharp:item/{nm}", "particle": f"sculkharp:item/{nm}"}, "elements": els, "display": DISPLAY}
    if st == 0: m["overrides"] = overrides
    save(nm, m); total += len(els)
    print(f"{nm}: {len(els)} elementos")
print("voxels:", len(cells), "| cordas:", len(STRING_COLS), "| elementos (4 modelos):", total)

# ---------------------------------------------------------------- sprites de partículas
PD = os.path.join(RES, "textures/particle"); os.makedirs(PD, exist_ok=True)
PD_J = os.path.join(RES, "particles"); os.makedirs(PD_J, exist_ok=True)
def sprite(rows, pal):
    h, w = len(rows), len(rows[0]); im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch in pal: im.putpixel((x, y), pal[ch] + (255,))
    return im
PAL = {"a": P4, "b": P3, "c": C1, "d": P2}
note0 = ["........", "...bbb..", "...baab.", "...b..b.", "...b....", "..bb....", ".baab...", "..bb...."]
note1 = ["........", "..bbbbb.", "..baaab.", "..b...b.", "..b...b.", ".bb..bb.", "baab.baab", "bbb..bbb"]
note1 = [r[:8] for r in note1]
shard0 = ["........", "..bbbb..", ".baaabb.", ".baaabb.", ".bbbbcb.", "..cccc..", "........", "........"]
shard1 = ["........", "...bb...", "..baab..", "..baab..", "...bb...", "........", "........", "........"]
shard1 = [r[:8] for r in shard1]
shard2 = ["........", "........", "..bbb...", ".baab...", ".bbbc...", "........", "........", "........"]
spark = ["...aa...", "...bb...", "...bb...", "aabaabaa", "aabaabaa", "...bb...", "...bb...", "...aa..."]
spark = [r[:8] for r in spark]
for nm, rows in (("sculk_note_0", note0), ("sculk_note_1", note1), ("sculk_shard_0", shard0), ("sculk_shard_1", shard1),
                 ("sculk_shard_2", shard2), ("sculk_spark", spark)):
    sprite(rows, PAL).save(os.path.join(PD, nm + ".png"))
# anel de energia 32x32 (contorno pixelado com degradê)
ring = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
for y in range(32):
    for x in range(32):
        d = ((x - 15.5) ** 2 + (y - 15.5) ** 2) ** 0.5
        if 13.0 <= d <= 15.6:
            t = (d - 13.0) / 2.6
            col = P4 if 0.35 < t < 0.65 else P3 if 0.15 < t < 0.85 else P2
            a = 255 if 0.2 < t < 0.8 else 150
            ring.putpixel((x, y), col + (a,))
ring.save(os.path.join(PD, "sculk_ring.png"))
def pj(nm, tex): json.dump({"textures": tex}, open(os.path.join(PD_J, nm + ".json"), "w"), indent=2)
pj("sculk_note", ["sculkharp:sculk_note_0", "sculkharp:sculk_note_1"])
pj("sculk_shard", ["sculkharp:sculk_shard_0", "sculkharp:sculk_shard_1", "sculkharp:sculk_shard_2"])
pj("sculk_spark", ["sculkharp:sculk_spark"])
pj("sculk_ring", ["sculkharp:sculk_ring"])
print("partículas: ok")
