package com.sculkharp;

import net.minecraftforge.common.ForgeConfigSpec;

/** Configuração da Harpa de Sculk (arquivo config/sculkharp-harp.toml). */
public final class HarpConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue CHARGE_TICKS;
    public static final ForgeConfigSpec.IntValue MIN_TICKS;
    public static final ForgeConfigSpec.IntValue PLUCK_INTERVAL;
    public static final ForgeConfigSpec.DoubleValue RADIUS;
    public static final ForgeConfigSpec.DoubleValue MIN_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue MAX_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue KNOCKBACK;
    public static final ForgeConfigSpec.IntValue COOLDOWN_TICKS;
    public static final ForgeConfigSpec.BooleanValue FIRST_PERSON_POSE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("sculk_harp");
        CHARGE_TICKS = b.comment("Ticks segurando para carga maxima (20 ticks = 1 s).")
                .defineInRange("chargeTicks", 36, 6, 200);
        MIN_TICKS = b.comment("Ticks minimos segurando para disparar a Onda de Ressonancia ao soltar (antes disso so toca notas).")
                .defineInRange("minTicks", 12, 1, 200);
        PLUCK_INTERVAL = b.comment("Intervalo, em ticks, entre as notas tocadas enquanto segura.")
                .defineInRange("pluckInterval", 6, 2, 40);
        RADIUS = b.comment("Raio da onda com carga maxima, em blocos (carga parcial usa de 50% a 100% disso).")
                .defineInRange("radius", 9.0D, 2.0D, 48.0D);
        MIN_DAMAGE = b.comment("Dano com carga minima (2 = 1 coracao).")
                .defineInRange("minDamage", 4.0D, 0.0D, 1000.0D);
        MAX_DAMAGE = b.comment("Dano com carga maxima.")
                .defineInRange("maxDamage", 14.0D, 0.0D, 1000.0D);
        KNOCKBACK = b.comment("Forca do empurrao para fora (0 desliga).")
                .defineInRange("knockback", 0.9D, 0.0D, 5.0D);
        COOLDOWN_TICKS = b.comment("Recarga apos a Onda de Ressonancia, em ticks.")
                .defineInRange("cooldownTicks", 60, 0, 1200);
        FIRST_PERSON_POSE = b.comment("Cliente: mostra as duas maos segurando a harpa em primeira pessoa. Se der problema visual, desligue.")
                .define("firstPersonPose", true);
        b.pop();
        SPEC = b.build();
    }

    private HarpConfig() { }
}
