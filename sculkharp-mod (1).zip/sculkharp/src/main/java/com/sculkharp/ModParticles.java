package com.sculkharp;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Partículas da Harpa de Sculk (sprites em textures/particle, definições em assets/.../particles). */
public class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, SculkHarpMod.MODID);

    /** Nota musical ciano. */
    public static final RegistryObject<SimpleParticleType> SCULK_NOTE = PARTICLES.register("sculk_note", () -> new SimpleParticleType(false));
    /** Fragmento quadrado de sculk que se desprende dos cristais. */
    public static final RegistryObject<SimpleParticleType> SCULK_SHARD = PARTICLES.register("sculk_shard", () -> new SimpleParticleType(false));
    /** Faísca em cruz (brilho de energia). */
    public static final RegistryObject<SimpleParticleType> SCULK_SPARK = PARTICLES.register("sculk_spark", () -> new SimpleParticleType(false));
    /** Anel de energia horizontal que se expande; xSpeed = raio final em blocos. */
    public static final RegistryObject<SimpleParticleType> SCULK_RING = PARTICLES.register("sculk_ring", () -> new SimpleParticleType(false));
}
