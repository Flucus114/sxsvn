package com.sculkharp;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Sons da Harpa de Sculk (arquivos .ogg em assets/sculkharp/sounds, mapeados em sounds.json). */
public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SculkHarpMod.MODID);

    public static final RegistryObject<SoundEvent> HARP_PLUCK = reg("harp_pluck");
    public static final RegistryObject<SoundEvent> HARP_CHARGE = reg("harp_charge");
    public static final RegistryObject<SoundEvent> HARP_WAVE = reg("harp_wave");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(SculkHarpMod.MODID, name)));
    }
}
