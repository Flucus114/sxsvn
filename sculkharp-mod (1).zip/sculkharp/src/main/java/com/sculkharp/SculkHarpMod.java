package com.sculkharp;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/** Sculk Harp: arma-instrumento de sculk (mod independente do Class Selector). */
@Mod(SculkHarpMod.MODID)
public class SculkHarpMod {
    public static final String MODID = "sculkharp";

    public SculkHarpMod() {
        var bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModTabs.TABS.register(bus);
        ModParticles.PARTICLES.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, HarpConfig.SPEC, "sculkharp.toml");
    }
}
